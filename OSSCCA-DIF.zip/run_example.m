clc; clear;

opts.alpha1 = 0.01;
opts.alpha2 = 0.01;
opts.lambda1 = 0.01;
opts.lambda2 = 0.01;
opts.gamma1 = 0.01;
opts.gamma2 = 0.01;
%% training and testing
X_0 = csvread('..\\ѵ�����Ͳ��Լ�\\x_train_smri_noname.csv');
Y_0 = csvread('..\\ѵ�����Ͳ��Լ�\\x_train_gene_noname.csv');
X_0 = getNormalization(X_0);
Y_0 = getNormalization(Y_0);
[nrow, ~] = size(X_0);
A = corr(X_0,X_0);
B = corr(Y_0,Y_0);

X_t = csvread('..\\ѵ�����Ͳ��Լ�\\x_test_smri_noname.csv');
Y_t = csvread('..\\ѵ�����Ͳ��Լ�\\x_test_gene_noname.csv');
X_t = getNormalization(X_t);
Y_t = getNormalization(Y_t);
Z = csvread('..\\ѵ�����Ͳ��Լ�\\y_train_smri_noname.csv');
tic;
[u1, v1] = DSCCA_FGL(X_0, Y_0, A, B, Z, opts);
[u2, v2] = SCCA_FGL(X_0, Y_0, opts);
[u3, v3] = SCCA(X_0, Y_0, opts);
[u4, v4] = CCA(X_0, Y_0, opts);
tt = toc;
corr_XY1 = corr(X_t*u1,Y_t*v1);
corr_XY2 = corr(X_t*u2,Y_t*v2);
corr_XY3 = corr(X_t*u3,Y_t*v3);
corr_XY4 = corr(X_t*u4,Y_t*v4);
%% results shown
% subplot(321)
% stem(u0);
% title('Ground truth: u');
% subplot(322)
% stem(v0);
% title('Ground truth: v');
subplot(211)
imagesc(u1', [-0.01 0.01]);
set(gca,'yticklabel',[])
title('Estimated u');
colorbar
subplot(212)
imagesc(v1', [-0.01 0.01]);
set(gca,'yticklabel',[])
title('Estimated v');
colorbar