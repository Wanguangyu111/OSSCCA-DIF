function [u, v] = OSSCCA_DIF(X, Y, A, B, Z, opts)
% --------------------------------------------------------------------
% Input:
%       - X, e.g., geno matrix
%       - Y, e.g., pheno matrix
%       - opts, parameters: alpha1, alpha2, lambda1, lambda2
% Output:
%       - u, weight of X
%       - v, weight of Y.
%------------------------------------------
% Author: Lei Du, dulei@nwpu.edu.cn
% Date created: 06/05/2017
% Updated: 02/26/2018
%% Copyright (C) 2016-2017 Lei Du
% -----------------------------------------

%% Problem
%
%  max  u' X 'Y v - 1/2*alpha1*||Xu||^2 - 1/2*alpha2*||Yv||^2 -
%  lambda1*||u||_FGL - lambda2*||v||_GGL
% --------------------------------------------------------------------

p = size(X,2);
q = size(Y,2);

% Calculate coverance within X and Y
XX = X'*X;
YY = Y'*Y;

% initialize w1 here
u0 = ones(p, 1);
% --------------------
% initialize w2 here
v0 = ones(q, 1);

u = u0;
v = v0;
% % scale u and v
scale = sqrt(u'*XX*u);
u = u./scale;
scale = sqrt(v'*YY*v);
v = v./scale;

% set parameters
alpha1 = opts.alpha1;
alpha2 = opts.alpha2;
lambda1 = opts.lambda1;
gamma1 = opts.gamma1;
gamma2 = opts.gamma2;

% get the structure
% Gu = updateGraph2(p,'FGL');
Gu = updateGraph2(p,'GGL');

% set stopping criteria
max_Iter = 100;
i = 0;
tol = 1e-5;
obj = [];
tv = inf;
tu = inf;

while (i<max_Iter && (tu>tol || tv>tol)) % default 100 times of iteration
    i = i+1;
    
    % update u
    % -------------------------------------
    % update diagnal matrix D1
%     D1 = updateD2(u,Gu,'FGL');
%     D1 = diag(D1);
      D1 = updateD2(u,Gu,'GGL');
      D1 = diag(D1);
    % solve u
    u_old = u;
    F1 = alpha1*XX+lambda1*D1+2* gamma1 * (u*u'-eye(p));
    Yv = Y*v;
    b1 = X'*Yv+X'*Z;
    u = F1\b1;
    
    % scale u
    scale = sqrt(u'*XX*u);
    u = u./scale;
    
    % update v
    % -------------------------------------
    % update diagnal matrix D2
%     D2 = updateD2(v,Gv,'GGL');
%     D2 = diag(D2);
    
    % solve v
    v_old = v;
    F2 = alpha2*YY+2* gamma2 * (v*v'-eye(q));
    Xu = X*u;
    b2 = Y'*Xu;
    v = F2\b2;
    
    % scale v
    scale = sqrt(v'*YY*v);
    v = v./scale;
    
    % stopping condition
    % -------------------------
    if i > 1
        tu = max(abs(u-u_old));
        tv = max(abs(v-v_old));
    else
        tu = tol*10;
        tv = tol*10;
    end
end
end